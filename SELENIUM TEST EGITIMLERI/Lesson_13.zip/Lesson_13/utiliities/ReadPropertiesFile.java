package Lesson_13.utiliities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadPropertiesFile {
    public static void main(String[] args) {
        Properties properties = new Properties();
        try {
            FileInputStream fileInputStream = new FileInputStream("C:\\Users\\barisa\\IdeaProjects\\Lesson_2_Methods\\src\\test\\java\\Lesson_13\\properties\\config.properties");
            properties.load(fileInputStream);
            fileInputStream.close();
            System.out.println(properties.getProperty("Username"));
            System.out.println(properties.getProperty("Password"));
            System.out.println(properties.getProperty("browser"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
